package com.hibernet.wakefit.entity;
import java.sql.Date;

import javax.persistence.Entity;
@Entity
public class Order 
{
	private int oID;
	private String orderTrackingNumber;
	private float totalPrice;
	private int oQuantity;
	private String status;
	private Date dateCreated;
	private Date lastUpdated;
	
	public Order() 
	{
		super();
	}
	public int getoID()
	{
		return oID;
	}
	public void setoID(int oID)
	{
		this.oID = oID;
	}
	public String getOrderTrackingNumber()
	{
		return orderTrackingNumber;
	}
	public void setOrderTrackingNumber(String orderTrackingNumber)
	{
		this.orderTrackingNumber = orderTrackingNumber;
	}
	public float getTotalPrice() 
	{
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice)
	{
		this.totalPrice = totalPrice;
	}
	public int getoQuantity() 
	{
		return oQuantity;
	}
	public void setoQuantity(int oQuantity)
	{
		this.oQuantity = oQuantity;
	}
	public String getStatus() 
	{
		return status;
	}
	public void setStatus(String status) 
	{
		this.status = status;
	}
	public Date getDateCreated()
	{
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated)
	{
		this.dateCreated = dateCreated;
	}
	public Date getLastUpdated() 
	{
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated)
	{
		this.lastUpdated = lastUpdated;
	}
	public Order(int oID, String orderTrackingNumber, float totalPrice, int oQuantity, String status, Date dateCreated,
			Date lastUpdated)
	{
		super();
		this.oID = oID;
		this.orderTrackingNumber = orderTrackingNumber;
		this.totalPrice = totalPrice;
		this.oQuantity = oQuantity;
		this.status = status;
		this.dateCreated = dateCreated;
		this.lastUpdated = lastUpdated;
	}
	@Override
	public String toString() {
		return "Order [oID=" + oID + ", orderTrackingNumber=" + orderTrackingNumber + ", totalPrice=" + totalPrice
				+ ", oQuantity=" + oQuantity + ", status=" + status + ", dateCreated=" + dateCreated + ", lastUpdated="
				+ lastUpdated + "]";
	}
	
	
}



	