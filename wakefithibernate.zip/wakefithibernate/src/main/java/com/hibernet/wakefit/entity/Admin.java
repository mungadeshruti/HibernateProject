package com.hibernet.wakefit.entity;


import javax.persistence.Entity;

@Entity
public class Admin
{
	private int aID;
	private String aName;
	private String Email;
	private int aMobNo;
	
	public Admin() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public int getaID()
	{
		return aID;
	}
	public void setaID(int aID)
	{
		this.aID = aID;
	}
	public String getaName() 
	{
		return aName;
	}
	public void setaName(String aName) 
	{
		this.aName = aName;
	}
	public String getEmail() 
	{
		return Email;
	}
	public void setEmail(String email)
	{
		Email = email;
	}
	public int getaMobNo() 
	{
		return aMobNo;
	}
	public void setaMobNo(int aMobNo) 
	{
		this.aMobNo = aMobNo;
	}
	public Admin(int aID, String aName, String email, int aMobNo) 
	{
		super();
		this.aID = aID;
		this.aName = aName;
		Email = email;
		this.aMobNo = aMobNo;
	}
	@Override
	public String toString() {
		return "Admin [aID=" + aID + ", aName=" + aName + ", Email=" + Email + ", aMobNo=" + aMobNo + "]";
	}
	
}


