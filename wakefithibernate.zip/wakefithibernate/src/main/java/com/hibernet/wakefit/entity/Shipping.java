package com.hibernet.wakefit.entity;
import javax.persistence.Entity;

@Entity
public class Shipping 
{
private int sID;
	
	
	public Shipping() 
	{
		super();
	}

	public int getsID() 
	{
		return sID;
	}
	public void setsID(int sID)
	{
		this.sID = sID;
	}
	public Shipping(int sID, String address)
	{
		super();
		this.sID = sID;
	}
	@Override
	public String toString()
	{
		return "Shipping [sID=" + sID + "]";
	}
}


