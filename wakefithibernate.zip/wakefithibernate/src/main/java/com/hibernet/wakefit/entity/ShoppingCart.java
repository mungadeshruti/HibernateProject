package com.hibernet.wakefit.entity;
import javax.persistence.Entity;

@Entity
public class ShoppingCart 
{
	private int id;
	private String imageUrl;
	private float unitPrice;
	private int quantity;
	private int productId;
	
	public ShoppingCart() 
	{
		super();
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getImageUrl()
	{
		return imageUrl;
	}
	public void setImageUrl(String imageUrl)
	{
		this.imageUrl = imageUrl;
	}
	public float getUnitPrice() 
	{
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice)
	{
		this.unitPrice = unitPrice;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}
	public int getProductId()
	{
		return productId;
	}
	public void setProductId(int productId)
	{
		this.productId = productId;
	}
	public ShoppingCart(int id, String imageUrl, float unitPrice, int quantity, int productId) 
	{
		super();
		this.id = id;
		this.imageUrl = imageUrl;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
		this.productId = productId;
	}
	@Override
	public String toString() 
	{
		return "Shopping [id=" + id + ", imageUrl=" + imageUrl + ", unitPrice=" + unitPrice + ", quantity=" + quantity
				+ ", productId=" + productId + "]";
	}
}


