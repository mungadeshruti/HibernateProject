package com.hibernet.wakefit.entity;
import java.sql.Date;

import javax.persistence.Entity;
@Entity
public class Product
{
	private int pID;
	private String pName;
	private String pDescription;
	private float pUnitPrice;
	private String pImageUrl;
	private boolean active;
	private int unitsInStock;
	private Date dateCreated;
	private Date lastUpdated;
	
	
	public Product() 
	{
		super();
	}
	public int getpID() 
	{
		return pID;
	}
	public void setpID(int pID)
	{
		this.pID = pID;
	}
	public String getpName()
	{
		return pName;
	}
	public void setpName(String pName) 
	{
		this.pName = pName;
	}
	public String getpDescription()
	{
		return pDescription;
	}
	public void setpDescription(String pDescription) 
	{
		this.pDescription = pDescription;
	}
	public float getpUnitPrice()
	{
		return pUnitPrice;
	}
	public void setpUnitPrice(float pUnitPrice)
	{
		this.pUnitPrice = pUnitPrice;
	}
	public String getpImageUrl() 
	{
		return pImageUrl;
	}
	public void setpImageUrl(String pImageUrl) 
	{
		this.pImageUrl = pImageUrl;
	}
	public boolean isActive() 
	{
		return active;
	}
	public void setActive(boolean active)
	{
		this.active = active;
	}
	public int getUnitsInStock()
	{
		return unitsInStock;
	}
	public void setUnitsInStock(int unitsInStock)
	{
		unitsInStock = unitsInStock;
	}
	public Date getDateCreated() 
	{
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) 
	{
		dateCreated = dateCreated;
	}
	public Date getLastUpdated()
	{
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) 
	{
		lastUpdated = lastUpdated;
	}
	
	public Product(int pID, String pName, String pDescription, float pUnitPrice, String pImageUrl, boolean active,
			int unitsInStock, Date dateCreated, Date lastUpdated) 
	{
		super();
		this.pID = pID;
		this.pName = pName;
		this.pDescription = pDescription;
		this.pUnitPrice = pUnitPrice;
		this.pImageUrl = pImageUrl;
		this.active = active;
		unitsInStock = unitsInStock;
		dateCreated = dateCreated;
		lastUpdated = lastUpdated;
	}
	@Override
	public String toString() 
	{
		return "Product [pID=" + pID + ", pName=" + pName + ", pDescription=" + pDescription + ", pUnitPrice="
				+ pUnitPrice + ", pImageUrl=" + pImageUrl + ", active=" + active + ", UnitsInStock=" + unitsInStock
				+ ", DateCreated=" + dateCreated + ", LastUpdated=" + lastUpdated + "]";
	}	 
}



