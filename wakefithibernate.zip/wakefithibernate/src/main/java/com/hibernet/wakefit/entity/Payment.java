package com.hibernet.wakefit.entity;
import java.sql.Date;

import javax.persistence.Entity;

@Entity
public class Payment 
{
	private int pID;
	private String pMethod;
	private Date pDate;
	private String status;

	public Payment() 
	{
		super();
	}
	public int getpID()
	{
		return pID;
	}
	public void setpID(int pID) 
	{
		this.pID = pID;
	}
	public String getpMethod()
	{
		return pMethod;
	}
	public void setpMethod(String pMethod)
	{
		this.pMethod = pMethod;
	}
	public Date getpDate() 
	{
		return pDate;
	}
	public void setpDate(Date pDate)
	{
		this.pDate = pDate;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public Payment(int pID, String pMethod, Date pDate, String status) 
	{
		super();
		this.pID = pID;
		this.pMethod = pMethod;
		this.pDate = pDate;
		this.status = status;
	}
	@Override
	public String toString() 
	{
		return "Payment [pID=" + pID + ", pMethod=" + pMethod + ", pDate=" + pDate + ", status=" + status + "]";
	}

	}


