package com.hibernet.wakefit.entity;

public class Catagory 
{

}

	