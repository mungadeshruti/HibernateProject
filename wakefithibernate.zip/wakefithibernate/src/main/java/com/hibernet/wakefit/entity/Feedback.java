package com.hibernet.wakefit.entity;
import javax.persistence.Entity;

@Entity
public class Feedback 
{
	private int fID;
	private String message;
	
	public Feedback() 
	{
		super();
	}
	public int getfID() 
	{
		return fID;
	}
	public void setfID(int fID)
	{
		this.fID = fID;
	}
	public String getMessage() 
	{
		return message;
	}
	public void setMessage(String message) 
	{
		this.message = message;
	}
	public Feedback(int fID, String message) 
	{
		super();
		this.fID = fID;
		this.message = message;
	}
	@Override
	public String toString() 
	{
		return "Feedback [fID=" + fID + ", message=" + message + "]";
	}
}


