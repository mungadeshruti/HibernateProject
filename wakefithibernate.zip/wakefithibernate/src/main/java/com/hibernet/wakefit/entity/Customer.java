package com.hibernet.wakefit.entity;
import javax.persistence.Entity;

@Entity
public class Customer 
{
	private int cID;
	private String cName;
	private String cEmail;
	private int cMobNo;
	private String cAddress;
	
	public Customer() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public int getcID() 
	{
		return cID;
	}
	public void setcID(int cID) 
	{
		this.cID = cID;
	}
	public String getcName()
	{
		return cName;
	}
	public void setcName(String cName) 
	{
		this.cName = cName;
	}
	public String getcEmail() 
	{
		return cEmail;
	}
	public void setcEmail(String cEmail)
	{
		this.cEmail = cEmail;
	}
	public int getcMobNo()
	{
		return cMobNo;
	}
	public void setcMobNo(int cMobNo)
	{
		this.cMobNo = cMobNo;
	}
	public String getcAddress()
	{
		return cAddress;
	}
	public void setcAddress(String cAddress) 
	{
		this.cAddress = cAddress;
	}
	public Customer(int cID, String cName, String cEmail, int cMobNo, String cAddress) 
	{
		super();
		this.cID = cID;
		this.cName = cName;
		this.cEmail = cEmail;
		this.cMobNo = cMobNo;
		this.cAddress = cAddress;
	}
	@Override
	public String toString() 
	{
		return "Customer [cID=" + cID + ", cName=" + cName + ", cEmail=" + cEmail + ", cMobNo=" + cMobNo + ", cAddress="
				+ cAddress + "]";
	}
	
}


